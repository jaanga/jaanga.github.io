A file for every day of the year
